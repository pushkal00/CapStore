
package com.capstore.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.capstore.dto.Product;
import com.capstore.dto.ProductFeedback;
import com.capstore.dto.Customer;
import com.capstore.dto.Merchant;
import com.capstore.dto.MerchantFeedback;

//import com.capstore.dto.MerchantDto;

@Controller
public class AdminController {

	@RequestMapping(method = RequestMethod.GET, value = "admin")
	public String index() {
		return "admin";
	}

	@RequestMapping(method = RequestMethod.GET, value = "/merchantdetails")
	public String merchant(ModelMap modelMap) {
		RestTemplate restTemplate = new RestTemplate();
		List<Merchant> response = new ArrayList<Merchant>();
		response = restTemplate.getForObject("http://localhost:7799/rest/merchantList", List.class);
		System.out.println("here");
		System.out.println(response);
		modelMap.put("merchantList", response);
		
		return "merchantDetails";
	}
	

	@RequestMapping(method = RequestMethod.GET, value = "/productdetails")
	public String product(ModelMap modelMap) {
		RestTemplate restTemplate = new RestTemplate();
		List<Product> response = new ArrayList<Product>();
		response = restTemplate.getForObject("http://localhost:7799/rest/productList", List.class);
		System.out.println("here");
		System.out.println(response);
		modelMap.put("productList", response);
		
		return "productDetails";
	}

	@RequestMapping(method = RequestMethod.GET, value = "/customerdetails")
	public String customer(ModelMap modelMap) {
		RestTemplate restTemplate = new RestTemplate();
		List<Customer> response = new ArrayList<Customer>();
		response = restTemplate.getForObject("http://localhost:7799/rest/customerList", List.class);
		modelMap.put("customerList", response);
		return "customerDetails";
	}
	
	//delete merchant
	@RequestMapping(method = RequestMethod.POST, value = "/deleteMerchants")
	public String Merchant(@RequestParam("id") String ids,ModelMap modelMap) {
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("hello Admin");
		//for(String id:ids) {
			System.out.println(ids);
		//}
		System.out.println("Pushkal");
		restTemplate.postForObject("http://localhost:7799/rest/delete?id="+ids, ids, String[].class);
		List<Merchant> response = new ArrayList<Merchant>();
		response = restTemplate.getForObject("http://localhost:7799/rest/merchantList", List.class);
		System.out.println("here");
		System.out.println(response);
		modelMap.put("merchantList", response);

		//modelMap.put("customerList", response);
		return "merchantDetails";
	}
	
	

	@RequestMapping(method = RequestMethod.POST, value = "/deleteProduct")
	public String Product(@RequestParam("id") String ids,ModelMap modelMap) {
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("hello Admin");
		//for(String id:ids) {
			System.out.println(ids);
		//}
		System.out.println("Pushkal");
		restTemplate.postForObject("http://localhost:7799/rest/deleteProduct?id="+ids, ids, String[].class);
		//modelMap.put("customerList", response);
		List<Product> response = new ArrayList<Product>();
		response = restTemplate.getForObject("http://localhost:7799/rest/productList", List.class);
		System.out.println("here");
		System.out.println(response);
		modelMap.put("productList", response);

		return "productDetails";
	}
	
	/*for adding merchant into database*/

	@RequestMapping(method = RequestMethod.GET, value = "/merchant")
	public String addNewMerchant(@ModelAttribute("merchant") Merchant merchant, ModelMap modelMap) {
		return "registerMerchant";
	}
	@RequestMapping(method=RequestMethod.POST,value="/addMerchant")
	public String list1(@ModelAttribute("merchant") Merchant merchant,ModelMap modelMap){
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Inside AdminController"+ merchant.getMerchantId());
		restTemplate.postForObject("http://localhost:7799/rest/addMerchant", merchant, Merchant.class);
		System.out.println(merchant.getMerchantName());
		List<Merchant> response = new ArrayList<Merchant>();
		
		response = restTemplate.getForObject("http://localhost:7799/rest/merchantList", List.class);
		System.out.println("here");
		System.out.println(response);
		modelMap.put("merchantList", response);


/*		RestTemplate restTemplatereceive = new RestTemplate();
		List<Merchant> response = new ArrayList<Merchant>();
		response = restTemplatereceive.getForObject("http://localhost:7799/rest/merchantList", List.class);
*/		//modelMap.put("merchantList", response);
		return "merchantDetails";

	
	}
	
	
	/*For adding product in the database*/
	
	@RequestMapping(method=RequestMethod.GET, value="/Product")
	public String product(@ModelAttribute("product") Product product, ModelMap map){
		return "addProduct1";
		
	}
	/*@Autowired
	RepoRestImpl dao;*/
	@RequestMapping(method=RequestMethod.POST,value="/addProduct")
	public String addNewProduct(@ModelAttribute("product") Product product,ModelMap map){
	/*	Merchant merchant=new Merchant(1);
		product.setMerchant(merchant);*/
		System.out.println("hello world");
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.postForObject("http://localhost:7799/rest/addProd", product, Product.class);
		System.out.println("ghghgh");
		System.out.println(product.getProductModel());
		List<Product> response = new ArrayList<Product>();
		response = restTemplate.getForObject("http://localhost:7799/rest/productList", List.class);
		System.out.println("here");
		System.out.println(response);
		map.put("productList", response);

		return "productDetails";
	

	}

	@RequestMapping(method=RequestMethod.GET, value="/Feedback")
	public String product(@ModelAttribute("proFeedback") ProductFeedback proFeedback, ModelMap map){
		System.out.println("Inside /Feedback");
		return "productFeedbackTest";
		
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/addFeedback")
	public String addNewProductFeedback(@ModelAttribute("proFeedback") ProductFeedback proFeedback,ModelMap modelMap){
	/*	Merchant merchant=new Merchant(1);
		product.setMerchant(merchant);*/
		System.out.println("hello world");
		//PRODUCT ID TO BE RECEIVED FROM SESSION
		proFeedback.setRating(4);
		int prod_id=1;		
		RestTemplate restTemplate = new RestTemplate();
		
		restTemplate.postForObject("http://localhost:7799/rest/addProductFeedback?id="+prod_id, proFeedback, ProductFeedback.class);
		System.out.println("ghghgh");
		//System.out.println(proFeedback.get);
		//TO CALL THE DISPLAY PAGE THAT FETCH THE VALUES
		return "productFeedbackTest";
	

	}
	
	
	@RequestMapping(method=RequestMethod.GET, value="/MerchantFeedback")
	public String Merchantproduct(@ModelAttribute("merchantFeedback") MerchantFeedback merchantFeedback, ModelMap map){
		System.out.println("Inside /MerchantFeedback");
		return "merchantFeedbackTest";
		
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/addMerchantFeedback")
	public String addNewMerchantFeedback(@ModelAttribute("merchantFeedback") MerchantFeedback merchantFeedback, ModelMap map){
	/*	Merchant merchant=new Merchant(1);
		product.setMerchant(merchant);*/
		System.out.println("hello world");
		//PRODUCT ID TO BE RECEIVED FROM SESSION
		merchantFeedback.setRating(4);
		int prod_id=1;		
		RestTemplate restTemplate = new RestTemplate();
		
		restTemplate.postForObject("http://localhost:7799/rest/addMerchantFeedback?id="+prod_id, merchantFeedback, MerchantFeedback.class);
		System.out.println("ghghgh");
		//System.out.println(proFeedback.get);
		//TO CALL THE DISPLAY PAGE THAT FETCH THE VALUES
		return "productFeedbackTest";
	

	}


	@ModelAttribute("merchant")
	public Merchant createMerchant() {
		return new Merchant();
	}
	@ModelAttribute("product")
	public Product createProduct() {
		return new Product();
	}
	
	
	@ModelAttribute("proFeedback")
	public ProductFeedback createFeedback() {
		return new ProductFeedback();
	}


}
