package com.capstore.Capstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableAutoConfiguration

@EntityScan("com.capstore.dto")
@ComponentScan("com.capstore.controller")
@ComponentScan("com.capstore.dto")
@ComponentScan("com.capstore.repo")
@ComponentScan("com.capstore.controller")
public class CapstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapstoreApplication.class, args);
	}

}
